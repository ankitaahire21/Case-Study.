
public  class MMCurrentAcc extends CurrentAcc{
	

	public MMCurrentAcc(int accNo, String accNm, float accBal, float creditLimit) {
		super(accNo, accNm, accBal, creditLimit);
	}

	@Override
	public void withdraw(float amount) {
		if(getAccBal()+ getCreditLimit() >=amount){
			setAccBal(getAccBal()-amount);
		}else{
			System.out.println("Amount is not available");
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
}
	
