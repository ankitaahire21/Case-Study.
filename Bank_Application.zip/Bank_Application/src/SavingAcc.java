
public abstract class SavingAcc extends BankAcc {
	
	private boolean isSalarised;
	private static float MIN_BALANCE=1000;
	
	public SavingAcc(int accNo, String accNm, float accBal, boolean isSalarised) {
		super(accNo, accNm, accBal);
		this.isSalarised = isSalarised;
	}
	
	@Override
	public abstract void withdraw(float amount);

	@Override
	public String toString() {
		return "SavingAcc ["+super.toString()+",isSalarised=" + isSalarised + "]";
	}
}
