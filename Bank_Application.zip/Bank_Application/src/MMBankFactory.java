
public   class MMBankFactory extends BankFactory{

	@Override
	public SavingAcc getNewSavingAccount(int accno, String accNm, float accBal, boolean isSalaried) {
		// TODO Auto-generated method stub
		return new MMSavingAcc(accno,accNm,accBal,isSalaried)  ;
	}
	

	@Override
	public CurrentAcc getNewCurrentAccount(int AccNo, String accNm, float accBal, float creditLimit) {
		// TODO Auto-generated method stub
		return new MMCurrentAcc(AccNo,accNm,accBal,creditLimit) ;
	}
	
}