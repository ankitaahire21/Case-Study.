
public  class MMSavingAcc extends SavingAcc {
	private static  float MINBALANCE=1000;

	public MMSavingAcc(int accNo, String accNm, float accBal, boolean isSalarised) {
		super(accNo, accNm, accBal, isSalarised);
	}

	@Override
	public void withdraw(float amount){
		if(getAccBal()-amount>=MINBALANCE){
			setAccBal(getAccBal()-amount);
		}else{
			System.out.println("Insufficient Balance");
		}
	}

	@Override
	public String toString() {
		return super.toString();
	}


	
	
	

}
