
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankFactory bankfactory=new MMBankFactory();
		SavingAcc savingacc=new MMSavingAcc(1234, "ankita", 10000, true);
		CurrentAcc currentAcc=new MMCurrentAcc(1245,"ritu",20000,2000);
				
		
		savingacc.withdraw(1000);
		currentAcc.withdraw(5000);
		
		System.out.println(savingacc.toString());
		System.out.println(currentAcc.toString());
				

	}

}
